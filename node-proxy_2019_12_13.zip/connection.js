function init(URL = 'mongodb://localhost/proxyAdmin')
{
	const mongoose = require('mongoose');

	// We need to difine the URL
	// var URL = process.env.URL || 'mongodb://localhost/proxyAdmin';

	mongoose.set('useCreateIndex', true);

	// Make Mongoose use `findOneAndUpdate()`. Note that this option is `true`
	// by default, you need to set it to false.
	mongoose.set('useFindAndModify', false);
	mongoose.set('useUnifiedTopology',true)
	//Connection establishment
	mongoose.connect(URL, {
	    useNewUrlParser: true,
	    useCreateIndex: true,
	});
	//Models
	// require('../model/user');
	var db = mongoose.connection;

	//We enebled the Listener
	db.on('error', () => {
	    console.error('Error occured in db connection');
	    process.exit();
	});

	db.on('open', () => {
	    console.log('DB Connection established successfully');
	});
}


module.exports = {init:init};