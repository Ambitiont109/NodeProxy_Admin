// HTTP forward proxy server that can also proxy HTTPS requests
// using the CONNECT method

// requires https://github.com/nodejitsu/node-http-proxy

var cluster = require('cluster'),
fs = require('fs');
const MasterServer = require('./master-server.js');

if (cluster.isMaster) {
  MasterServer.run();
} else {
  const isThroughProxy = false;
  const authKey = process.env.PROXY_AUTH_KEY || undefined;
  const MaximumDataUsageSize = process.env.MaximumDataUsageSize * 1024 * 1024;
  // const authKey = "Basic YWE6MTIz"
  const proxyHeader = 'proxy-authorization';
  var httpProxy = require('http-proxy'),
      url = require('url'),
      net = require('net'),
      http = require('http');
  var {init} = require('./connection');
  init(process.env.dbURL || 'mongodb://localhost/proxyAdmin');
  const {UserModel, LogModel, DataUsageLogModel} = require('./model');

  var HttpProxyAgent = require('http-proxy-agent');

  const listening_port = process.env.PORT || 3333;
  process.on('uncaughtException', logError);
  function truncate(str) {
    var maxLength = 64;
    return str.length >= maxLength ? str.substring(0, maxLength) + '...' : str;
  }

  function logRequest(req) {
    console.log(req.method + ' ' + truncate(req.url));
    for (var i in req.headers)
      console.log(' * ' + i + ': ' + truncate(req.headers[i]));
  }

  function logError(e) {
    console.warn('*** ' + e);
  }
  function UpdateProxyLog(username, responseSize, siteAddress=''){
    if(username){
      // DataUsageLogModel.updateOne({username:username}, {$inc:{dataUsage:responseSize}},{upsert:true}, function(err, res) {

      //   // console.log('======== Update dataUsage ========');
      //   console.log(err,res);
      // });
      DataUsageLogModel.findOneAndUpdate({username:username}, {$inc: {dataUsage:responseSize}}, {upsert:true, new:true}, function(err,res) {
        console.log(err, res);
      });
      LogModel.updateOne({
                          username:username, 
                          siteAddress:siteAddress
                          },
                          {
                            $set:{
                              lastVisitedTime:Date.now()
                            }
                          },
                          {
                            upsert:true
                          },
                          function(err, res){
                            // console.log(err,res);
                          });
    }
  }
  async function doDataLimitCheck(username, MaximumDataUsageSize){
    if(username){
      let dataUsageLog = await DataUsageLogModel.findOne({username:username}).exec();
      let mb_value = dataUsageLog.dataUsage/1024/1024;
      mb_value = Number(mb_value.toFixed(2))
      if(mb_value >= MaximumDataUsageSize){
        return false;
      }
      return true;
    }
    return false
  }
  
  function IsExpired(user /*UserModel*/) {
    if(! user.expiredDate){
      return true;
    }
    const currentdate = new Date();
    if(currentdate >= user.expiredDate){
      return true;
    }
    return false;
  }

  async function doAuthentication(auth_header) {
    let auth_values = auth_header.split(' ',2);
    if (auth_values[0] != 'Basic')    return false;
    let auth_key = auth_values[1];
    let username,pwd;
    let credentials = Buffer.from(auth_key,'base64').toString().split(':',2);
    console.log(credentials);
    username = credentials[0];
    pwd = credentials[1];
    console.log(username, pwd);
    console.log("=============")
    let user = await UserModel.findOne({username:username}).exec();

    console.log(user);
    if(user){
      if(pwd == user.password){
        return user
      }
    }
    return undefined;
  }  
  function sendDataLimitOverError(res, string) {
    res.writeHead(406, {
      'Content-type': 'text/plain',      
    });
    res.end(string);
  }

  function getUsernameFromAuthHeader(auth_header){
    let auth_values = auth_header.split(' ',2);
    if (auth_values[0] != 'Basic')    return undefined;
    let auth_key = auth_values[1];
    let username,pwd;
    let credentials = Buffer.from(auth_key,'base64').toString().split(':',2);
    console.log(credentials);
    return credentials[0];
  }
  function do407Response(res, optional_header={}) {
    res.writeHead( 407,{'Proxy-Authenticate': 'Basic realm=\"Test\"', 
                        'Content-type': 'text/html'});  
  }
  let routeTable = {
  }

  //
  // this proxy will handle regular HTTP requests
 

  // standard HTTP server that will pass requests
  // to the proxy
  var proxyinfo = process.env.PROXY || "ca.smartproxy.com:20000:rycao18:Unknown";
  proxyinfo = proxyinfo.split(':');
  let proxy_host = proxyinfo[0],
      proxy_port = proxyinfo[1],
      proxy_user = proxyinfo[2],
      proxy_pwd = proxyinfo[3];

  
  var server = http.createServer(async function(req, res) {    
    //   console.log('via normal http');
    logRequest(req);
    console.log(req.headers[proxyHeader])
    if(! req.headers[proxyHeader]) {
      do407Response(res);
      res.end('No Auth Header Received');
      return;
    }
    let user = await doAuthentication(req.headers[proxyHeader])
    if(! user) {
      do407Response(res, {'Proxy-Authorization': 'Not Authenticated'});
      res.end('Proxy-Authorization: Not Authenticated');
      return;
    } else {
      let portRange = user.portRange;
      if (!(listening_port >= portRange.start && listening_port <= portRange.end)){
        res.writeHead(406);
        res.end(`Port ${listening_port} is not acceptable.`);
        return ;
      }
    }
    if(IsExpired(user)){
      res.writeHead(410);
      res.end('Expired.');
      return;
    }
    let username = getUsernameFromAuthHeader(req.headers[proxyHeader]);
    let hostaddress = req.headers.host.toLowerCase();
    let dataLimitCheck = await doDataLimitCheck(username, user.dataLimit);
    if(!dataLimitCheck){
      sendDataLimitOverError(res,"DataUsage is over the limit");
      return;
    }

    delete req.headers[proxyHeader];    
    console.log(proxyinfo)
    var regularProxy = new httpProxy.createProxyServer();
    
    regularProxy.on('proxyRes', function (proxyRes, req, res) {
      // console.log(proxyRes)
      // console.log('RAW Response from the target', JSON.stringify(proxyRes.headers, true, 2));
      console.log(proxyRes.headers)      
      var bodySize = 0;
      if(proxyRes.headers['content-length']){
        let responseSize = Number(proxyRes.headers['content-length']);
        UpdateProxyLog(username, responseSize, hostaddress);
        
      }
      else{

        proxyRes.on('data' , function(dataBuffer){         
            bodySize += dataBuffer.length;
        });
        proxyRes.on('end', function() {
          let responseSize = bodySize;
          UpdateProxyLog(username, responseSize, hostaddress);
        })
       } 

    });
    if (! isThroughProxy) {
      regularProxy.web(req, res, { target: 'http://'+req.headers.host});
    } else {
      regularProxy.web(req, res, { target: 'http://'+req.headers.host, agent: new HttpProxyAgent(`http://${proxy_user}:${proxy_pwd}@${proxy_host}:${proxy_port}`)});
    }
    
    // regularProxy.web(req, res, { target: 'http://'+req.headers.host, agent: new HttpProxyAgent("http://rycao18:Unknown@ca.smartproxy.com:20000")});
    
  });

  // when a CONNECT request comes in, the 'connect'
  // event is emitted
  server.on('connect', async function(req, socket, head) {
    console.log('via connect');

    // logRequest(req);
    console.log(req.headers)
    if(!req.headers[proxyHeader]) {
      let responseHeader =  `HTTP/${req.httpVersion} 407 Proxy Authentication Required\r\n` +
                      'Proxy-Authenticate: Basic realm="Test"\r\n' +
                      'Transfer-Encoding: chunked\r\n' +
                      'Content-type: text/html\r\n\r\n';
      socket.write(responseHeader);
      socket.write('23\r\nNo Auth Header Received');
      socket.end('0\r\n\r\n');
      socket.destroy();
      return;
    }

    let user = await doAuthentication(req.headers[proxyHeader])
    if(! user) {
      let responseHeader =  `HTTP/${req.httpVersion} 407 Proxy Authentication Required\r\n` +
                      'Proxy-Authenticate: Basic realm="Test"\r\n' +
                      'Transfer-Encoding: chunked\r\n' +
                      'Content-type: text/html\r\n\r\n';
      socket.write(responseHeader+'38\r\nProxy-Authorization: Not Authenticated'+'0\r\n\r\n');
      // socket.write('38\r\nProxy-Authorization: Not Authenticated');
      // socket.end('0\r\n\r\n');
      socket.destroy();
      return;
    }else{      
      let portRange = user.portRange;
      console.log(user)
      if (!(listening_port >= portRange.start && listening_port <= portRange.end)){
        let responseHeader =  `HTTP/${req.httpVersion} 406 Not Acceptable\r\n` +
                        'Transfer-Encoding: chunked\r\n' +
                        'Content-type: text/html\r\n\r\n';
        let response_string = `Port ${listening_port} is not acceptable.`;
        let len = response_string.length;
        socket.write(responseHeader+`${len}\r\n${response_string}`+'0\r\n\r\n');
        // socket.write('38\r\nProxy-Authorization: Not Authenticated');
        // socket.end('0\r\n\r\n');
        socket.destroy();
        return ;
      }
    }
    if(IsExpired(user)){
        let responseHeader =  `HTTP/${req.httpVersion} 410 Gone\r\n` +
                        'Transfer-Encoding: chunked\r\n' +
                        'Content-type: text/html\r\n\r\n';
        let response_string = `Expired.`;
        let len = response_string.length;
        socket.write(responseHeader+`${len}\r\n${response_string}`+'0\r\n\r\n');
        // socket.write('38\r\nProxy-Authorization: Not Authenticated');
        // socket.end('0\r\n\r\n');
        socket.destroy();
        return ;
      return;
    }
    let username = getUsernameFromAuthHeader(req.headers[proxyHeader]);
    let dataLimitCheck = await doDataLimitCheck(username, user.dataLimit);
    if(!dataLimitCheck){
      let responseHeader =  `HTTP/${req.httpVersion} 406 Not Acceptable\r\n` +
                      'Transfer-Encoding: chunked\r\n' +
                      'Content-type: text/plain\r\n\r\n';
      let response_string = `DataUsage is over the limit`;
      let len = response_string.length;
      socket.write(responseHeader+`${len}\r\n${response_string}`+'0\r\n\r\n');
      // socket.write('38\r\nProxy-Authorization: Not Authenticated');
      // socket.end('0\r\n\r\n');
      socket.destroy();
      return ;
      sendDataLimitOverError(res,"DataUsage is over the limiation");
      return;
    }

    // URL is in the form 'hostname:port'
    var parts = req.url.split(':', 2);
    let hostaddress = parts[0].toLowerCase();
    console.log(parts)
    // open a TCP connection to the remote host
    if (!isThroughProxy){
      proxy_port = parts[1];
      proxy_host = parts[0];
    } 
    var conn = net.connect(
      // 20000,
      // "ca.smartproxy.com",
      Number(proxy_port),
      proxy_host,
      // parts[1],
      // parts[0],
      function() {
        // let auth = Buffer.from('rycao18:Unknown');
        if(isThroughProxy){
          let auth = Buffer.from(`${proxy_user}:${proxy_pwd}`);
          req.headers[proxyHeader] = 'Basic ' + auth.toString('base64');
          var rawRequestData = 'CONNECT '+ req.url + ' HTTP/'+req.httpVersion + '\r\n';
          // console.log(req.method + ' ' + truncate(req.url));
          for (var i in req.headers)
            rawRequestData = rawRequestData + (i + ': ' + req.headers[i] + '\r\n');
          // console.log(rawRequestData)
          conn.write(rawRequestData + '\r\n');          
        } else {
          socket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
        }


        
        var size = 0;

        conn.on('data', function(chunk) {
          size += chunk.length;
          // console.log('==connect==');
          // console.log(size, chunk.length)
          // UpdateProxyLog(username, chunk.length, hostaddress);
        })
        socket.on('end', function(){
          UpdateProxyLog(username, size, hostaddress);
          console.log("Soccket Closed");
        })
        conn.pipe(socket);
        socket.pipe(conn);
      }
    );
  });
  
  server.listen(listening_port,'0.0.0.0');
  console.log(`${listening_port} is running`);
}


