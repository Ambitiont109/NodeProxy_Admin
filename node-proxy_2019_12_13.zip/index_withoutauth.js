// HTTP forward proxy server that can also proxy HTTPS requests
// using the CONNECT method

// requires https://github.com/nodejitsu/node-http-proxy
const authKey = process.env.PROXY_AUTH_KEY || undefined;
// const authKey = "Basic YWE6MTIz"
const proxyHeader = 'proxy-authorization';
var httpProxy = require('http-proxy'),
  cluster = require('cluster'),
  url = require('url'),
  net = require('net'),
  fs = require('fs'),
  http = require('http');

var HttpProxyAgent = require('http-proxy-agent');


process.on('uncaughtException', logError);
function truncate(str) {
  var maxLength = 64;
  return str.length >= maxLength ? str.substring(0, maxLength) + '...' : str;
}

function logRequest(req) {
  console.log(req.method + ' ' + truncate(req.url));
  for (var i in req.headers)
    console.log(' * ' + i + ': ' + truncate(req.headers[i]));
}

function logError(e) {
  console.warn('*** ' + e);
}

function doAuthentication(auth_header) {
  let auth_values = auth_header.split(' ',2);
  if (auth_values[0] != 'Basic')    return false;
  let auth_key = auth_values[1];
  let username,pwd;
  let credentials = Buffer.from(auth_key,'base64').toString().split(':',2);
  console.log(credentials);
  username = credentials[0];
  pwd = credentials[1];
  console.log(username, pwd);
  if (username !== 'aa')
    return false;  
  return true;
}

function do407Response(res, optional_header={}) {
  res.writeHead( 407,{'Proxy-Authenticate': 'Basic realm=\"Test\"', 
                      'Content-type': 'text/html'});  
}
let routeTable = {
}


if (cluster.isMaster) {
  console.log(`Master ${process.pid} is running`);
  let jsonContent;
  try{
    let content = fs.readFileSync('init.json');
    jsonContent = JSON.parse(content);
    console.log(jsonContent);
  } catch (err){
    logError(err);
    return;
  }
  routeTable = jsonContent['RouteTable'];
  var numberOfPorts = Object.keys(routeTable).length;
  // Fork workers.
  Object.keys(routeTable).forEach(function(key) {
    cluster.fork({PORT:key, PROXY:routeTable[key]});
  });
} else {
  //
  // this proxy will handle regular HTTP requests
  var regularProxy = new httpProxy.createProxyServer();

  // standard HTTP server that will pass requests
  // to the proxy
  var proxyinfo = process.env.PROXY || "ca.smartproxy.com:20000:rycao18:Unknown";
  proxyinfo = proxyinfo.split(':');
  let proxy_host = proxyinfo[0],
      proxy_port = proxyinfo[1],
      proxy_user = proxyinfo[2],
      proxy_pwd = proxyinfo[3];
  var server = http.createServer(function(req, res) {
    //   console.log('via normal http');
    logRequest(req);
    console.log(req.headers[proxyHeader])
    if(!req.headers[proxyHeader]) {
      do407Response(res);
      res.end('No Auth Header Received');
      return;
    }
    if(!doAuthentication(req.headers[proxyHeader])) {
      do407Response(res, {'Proxy-Authorization': 'Not Authenticated'});
      res.end('Proxy-Authorization: Not Authenticated');
      return;
    }
    delete req.headers[proxyHeader];    
    console.log(proxyinfo)
    // regularProxy.web(req, res, { target: 'http://'+req.headers.host});
    // regularProxy.web(req, res, { target: 'http://'+req.headers.host, agent: new HttpProxyAgent("http://rycao18:Unknown@ca.smartproxy.com:20000")});
    regularProxy.web(req, res, { target: 'http://'+req.headers.host, agent: new HttpProxyAgent(`http://${proxy_user}:${proxy_pwd}@${proxy_host}:${proxy_port}`)});
  });

  // when a CONNECT request comes in, the 'connect'
  // event is emitted
  server.on('connect', function(req, socket, head) {
      console.log('via connect');
    // logRequest(req);
    console.log(req.headers)
    if(!req.headers[proxyHeader]) {
      let responseHeader =  `HTTP/${req.httpVersion} 407 Proxy Authentication Required\r\n` +
                      'Proxy-Authenticate: Basic realm="Test"\r\n' +
                      'Transfer-Encoding: chunked\r\n' +
                      'Content-type: text/html\r\n\r\n';
      socket.write(responseHeader);
      socket.write('23\r\nNo Auth Header Received');
      socket.end('0\r\n\r\n');
      socket.destroy();
      return;
    }
    if(!doAuthentication(req.headers[proxyHeader])) {
      let responseHeader =  `HTTP/${req.httpVersion} 407 Proxy Authentication Required\r\n` +
                      'Proxy-Authenticate: Basic realm="Test"\r\n' +
                      'Transfer-Encoding: chunked\r\n' +
                      'Content-type: text/html\r\n\r\n';
      socket.write(responseHeader+'38\r\nProxy-Authorization: Not Authenticated'+'0\r\n\r\n');
      // socket.write('38\r\nProxy-Authorization: Not Authenticated');
      // socket.end('0\r\n\r\n');
      socket.destroy();
      return;
    }

    // URL is in the form 'hostname:port'
    var parts = req.url.split(':', 2);
    console.log(parts)
    // open a TCP connection to the remote host
    var conn = net.connect(
      // 20000,
      // "ca.smartproxy.com",
      Number(proxy_port),
      proxy_host,
      // parts[1],
      // parts[0],
      function() {
        // let auth = Buffer.from('rycao18:Unknown');
        let auth = Buffer.from(`${proxy_user}:${proxy_pwd}`);
        req.headers[proxyHeader] = 'Basic ' + auth.toString('base64');
        var rawRequestData = 'CONNECT '+ req.url + ' HTTP/'+req.httpVersion + '\r\n';
        console.log(req.method + ' ' + truncate(req.url));
        for (var i in req.headers)
          rawRequestData = rawRequestData + (i + ': ' + req.headers[i] + '\r\n');
        console.log(rawRequestData)
        conn.write(rawRequestData + '\r\n');
        // socket.write('HTTP/1.1 200 Connection Established\r\n\r\n');      
        conn.pipe(socket);
        socket.pipe(conn);
      }
    );
  });
  const port = process.env.PORT || 3333;
  server.listen(port);
  console.log(`${port} is running`);
}


