var cluster = require('cluster'),
 fs = require('fs');
const runningWorkers={
  "portNumber":"workerId"
}
const CONFIG={
  dbURL:'',
  secretKey:'',
  MaximumDataUsageSize: 10.0
}

const express = require('express')
const app = express()
app.use(express.json());
const AdminPort = 5000

function storeForkedWorkers(workerId, portNumber)
{
  runningWorkers[portNumber] = workerId;
}

function isWorkerRunning(portNumber){
  if (! runningWorkers.hasOwnProperty(portNumber)){
    return false;
  }
  const workerId = runningWorkers[portNumber];
  const worker = cluster.workers[workerId];
  if(worker == undefined || worker.isDead()){
    delete runningWorkers[portNumber]; 
    return false;    
  }
  return true;
}

function SendKillSignal(portNumber){
  return new Promise(function(resolve, reject) {
    if(portNumber == AdminPort)
      reject({status:'fail', msg:'Can\'t kill AdminPort '});
    console.log(isWorkerRunning(portNumber));
    if (! isWorkerRunning(portNumber))
    {
      resolve({status:'success',msg:`Killed Process which is listening on port ${portNumber}`});
    }
    else{
      const workerId = runningWorkers[portNumber];
      const worker = cluster.workers[workerId];
      worker.on('exit', (code,sig) => {
        console.log(worker)
        console.log(worker.isDead())
        console.log("Killllllllllllllllllllllllllled ===============");
        resolve({'status':'success', msg:`Killed Process which is listening on port ${portNumber}`});
      });
      console.log(worker)
      // Try 3 killing 
      const numberOfTryCount = 3;
      for (var i = numberOfTryCount; i >= 0; i--) {
        setTimeout((param1, worker)=>{
          console.log("Try Killing : Number " + param1, worker); 
          if(! worker.isDead()){
            if(param1 >= numberOfTryCount){
              reject({'status':'fail',msg: 'Failed on Killing'});
            } else {
              worker.kill();
            }
          }        
        }, 3000 * i, i,worker);
      }
    }      
      
  });
}

function CreateWorker(portNumber, proxyInfo){
  return new Promise(function(resolve, reject) {
    if(portNumber == AdminPort)
      reject({status:'fail', msg:'Can\'t kill AdminPort '})
    if(isWorkerRunning(portNumber)){
      reject({'status':'fail', msg:'SomeOtherProcess is using port' + portNumber});
    }else {
      const worker = cluster.fork({PORT:portNumber, PROXY:proxyInfo, dbURL: CONFIG.dbURL, MaximumDataUsageSize: CONFIG.MaximumDataUsageSize});
      storeForkedWorkers(worker.id, portNumber);
      resolve({'status': 'success','pid':worker.process.pid});
    }
  });
}

function ApiAuthenticated(req, res, next){
  console.log(req.headers)
  if (!('authorization' in req.headers)){
    console.log("===================");
    res.status(401).json({'message':'UnAuthorized'});
    return;
  }
  auth_header = req.headers['authorization'];
  if (auth_header !== CONFIG.secretKey)
  {
    res.status(401).json({'message':'UnAuthorized'});
    return;    
  }
  return next();
}

app.get('/', (req, res) => res.send('Hello World!'))
app.post('/create',ApiAuthenticated,(req,res) => {  
  if(req.body == undefined)
    return res.status(400).json({'message': 'Error'});
  const portNumber = req.body['portNumber'];
  const proxyInfo = req.body['proxyInfo'];
  if(portNumber == undefined || proxyInfo == undefined)
    return res.status(400).json({'message': 'Error'});

  if(portNumber == AdminPort)
    return res.json({'status':'ADMIN_PORT'});
  SendKillSignal(portNumber).then(
    (success) => {
      CreateWorker(portNumber, proxyInfo).then(
        (success)=>{
          res.json({'status':'SUCCESS','pid':success.pid});
        }, 
        (err) => {
          console.log(err);
          res.json({'status':'CREATE_FAIL', 'msg':err.msg})
      });
    }, 
    (err) => {
      console.log(err)
      res.json({'status':'KILL_FAIL','msg':err.msg});
  });
});

app.post('/delete',ApiAuthenticated,(req,res) => {
  const portNumber = req.body['portNumber'];
  if(portNumber == AdminPort)
    return res.json({'status':'ADMIN_PORT'});
  SendKillSignal(portNumber).then(
    (success) => {
      res.json({'status':'success'});
    }, 
    (err) => {
      res.json({'status':'KILL_FAIL'});
  });
});



function run(){
  if(! cluster.isMaster)
    return;
  fs.writeFileSync('master.pid', process.pid);
  const proxyTable={};
  //Load init.json
  let jsonContent;
  try{
    let content = fs.readFileSync('init.json');
    jsonContent = JSON.parse(content);
    console.log(jsonContent);
  } catch (err){
    logError(err);
    return;
  }
  routeTable = jsonContent['RouteTable'];
  var numberOfPorts = Object.keys(routeTable).length;  
  CONFIG.dbURL = jsonContent['DataBaseUrl'];
  CONFIG.secretKey = jsonContent['SecretKey'];
  CONFIG.MaximumDataUsageSize = jsonContent['MaximumDataSize'];
  //Fork Child Proces Workers
  Object.keys(routeTable).forEach(function(key) {
    const portNumber = key;
    const worker = cluster.fork({PORT:portNumber, PROXY:routeTable[key], dbURL: jsonContent['DataBaseUrl'], MaximumDataUsageSize: CONFIG.MaximumDataUsageSize});
    storeForkedWorkers(worker.id, portNumber);
  });
  app.listen(AdminPort,'0.0.0.0', () => console.log(`Master Admin app listening on port ${AdminPort}!`))
}

module.exports = {run:run};