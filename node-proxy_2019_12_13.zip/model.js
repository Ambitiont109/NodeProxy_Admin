var mongoose = require('mongoose');

var schema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        unique: true
    },
    firstName: {
        type: String,
        default: ''
    },
    lastName: {
        type: String,
        default: ''
    },
    password:String,
    email:{
        type: String,
        unique: true,
        default: ''
    },
    portRange:{
        type:{ start: Number, end: Number},
        default: {start : 20000,end : 30000}
    },
    role: {
        type:String,
        default:'User'
    },
    dataLimit:{
        type:Number,
        default:10  // 10MB
    },
    expiredDate:{
        type:Date,
        default: Date.now
    }
});
var DataUsageLogSchema = new mongoose.Schema({
    username:{
        type:String,
        required: true,
        unique:true
    },
    dataUsage: {
        type:Number,
        default:0.0
    }
}) 
var LogSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
    },
    siteAddress: {
        type:String,
        required:true        
    },
    lastVisitedTime:{
        type: Date,
        required:true
    }
});
var UserModel = new mongoose.model('User', schema);
var LogModel = new mongoose.model('Log', LogSchema);
var DataUsageLogModel = new mongoose.model('DataUsageLog', DataUsageLogSchema);
module.exports = {UserModel, LogModel, DataUsageLogModel};