const Bcrypt = require("bcryptjs");	
const prompt = require('prompt');
let email ='';
let password =''
const properties = [
    {
        name: 'Email',
        validator: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
        warning: 'Input Correct Email Addresss'
    },
    {
        name: 'Password',
        hidden: true
    }
];


function createsuperuser(email,password){
	const {UserModel} = require('./model/user');
	require('./config/connection');
	
	let encpassword = Bcrypt.hashSync(password, 10);
	let user = new UserModel({email:email, password:encpassword, username:email, role:'Admin'});
	user.save().then((response) => {
		console.log("superuser created successfully");
		console.log('	Email: ' + email);
		console.log('	Password: ' + password);
		process.exit();
	    }, (error) => {
	      console.log("creating superuser failed");
	      if(error.name == 'ValidationError')
	      	console.log("Email alrady exists")
	    process.exit();
	});
}

prompt.start();

prompt.get(properties, function (err, result) {
    if (err) { return onErr(err); }
    console.log('  Email: ' + result.Email);
    console.log('  Password: ' + result.Password);
    email = result.Email;
    password = result.Password;
    createsuperuser( email, password);
});

function onErr(err) {
    console.log(err);
    return 1;
}
