var express = require('express');
var mongoose = require('mongoose');
const Bcrypt = require("bcryptjs");

function isAuthenticated(req, res, next) {
  // do any checks you want to in here

  // CHECK THE USER STORED IN SESSION FOR A CUSTOM VARIABLE
  // you can do this however you want with whatever variables you set up
  console.log(req.session)

  console.log(req.current_user)
  if (req.session.current_user)
      return next();

  // IF A USER ISN'T LOGGED IN, THEN REDIRECT THEM SOMEWHERE
  res.redirect('/login');
}

function ApiAuthenticated(req, res, next){
  console.log(req.headers)
  if (!('authorization' in req.headers)){
    console.log("===================");
    res.status(401).json({'message':'UnAuthorized'});
    return;
  }
  auth_header = req.headers['authorization'];
  authKey = auth_header.split(' ',2)[1];
  let username,pwd;
  let credentials = Buffer.from(authKey,'base64').toString().split(':',2);
  username = credentials[0];
  pwd = credentials[1];

  var UserModel = mongoose.model('User');
  UserModel.findOne({username: username}, function(err, user) {
    console.log("Find one");
    console.log(user)
    console.log(err)
      if (err) throw err;
      if(!user){
        res.status(401).json({'message':'UnAuthorized'});
        return;
      } else if (user){
        if(!Bcrypt.compareSync(pwd, user.password))
          return res.status(401).json({'message':'UnAuthorized'});
        else{
          return next();
        }
      }     
  });
}
module.exports = {
	isAuthenticated: isAuthenticated,
  ApiAuthenticated:ApiAuthenticated
}

