var express = require('express');
var mongoose = require('mongoose');

var router = express.Router();
var utils = require('../utils.js');
var {isAuthenticated} = require('../middleware.js');
var UserModel = mongoose.model('User');
var DataUsageLogModel = mongoose.model('DataUsageLog');
var LogModel = mongoose.model('Log');
var Joi = require('joi');
var validate = require('express-validation');
var {ApiAuthenticated} = require('../middleware.js');
const request = require('request');
const AdminPort = 5000;
const SecretKey = '6v9y$B&E)H@McQfTjWnZr4u7w!z%C*F-JaNdRgUkXp2s5v8y/A?D(G+KbPeShVmY';
createUserValidation = {
  body:{
    firstName: Joi.string(),
    lastName: Joi.string(),
    username: Joi.string().alphanum().min(3).max(30).required(),
    password: Joi.string().required().min(3),
    dataLimit: Joi.number(),
    expiredDate: Joi.date(),
    portMin: Joi.number().integer().required(),
    portMax: Joi.number().integer().required()
  }
}

updateDataLimitValidation = {
  body: {
    dataLimit: Joi.number().required()
  }
}

updateExpiredDateValidation = {
  body: {
    expiredDate: Joi.date().iso().required()
  }  
}

createPortValidation = {
  body: {
    server:Joi.string().ip().required(),
    port: Joi.number().integer().required(),
    path: Joi.string().required()
  }
}

deletePortValidation = {
  body: {
    server:Joi.string().ip().required(),
    port: Joi.number().integer().required()
  }
}
router.post('/createUser',ApiAuthenticated,validate(createUserValidation), function(req, res) {
  console.log(req.body);
  req.body['portRange']={start:req.body.portMin, end:req.body.portMax};
  let user = new UserModel(req.body);
  user.save().then((response) => {
      let dataDoc = new DataUsageLogModel({username:user.username, dataUsage:0});
      dataDoc.save();
      res.status(200).json({'message':'Created the user successfully.'});
    }, (error) => {
      res.status(400).json(error);
  });
});

router.post('/updateDataLimit/:username',ApiAuthenticated,validate(updateDataLimitValidation), function(req, res) {
  console.log(req.body);
  let username = req.params.username;
  UserModel.findOne({username:username, role:'User'}, function(err, user) {
    if (err || !user){
      return res.status(400).json({'message':'User not found'});
    }
    else{
      user.dataLimit = req.body['dataLimit'];
      user.save().then((response) => {
        res.status(200).json({'message':'updateDataLimit Successfully',"user":response});
      }, (error) => {
        res.status(400).json(error);
      })
    }
  });
});

router.post('/updateExpiredDate/:username',ApiAuthenticated,validate(updateExpiredDateValidation), function(req, res) {
  console.log(req.body);
  let username = req.params.username;
  UserModel.findOne({username:username, role:'User'}, function(err, user) {
    if (err || !user){
      return res.status(400).json({'message':'User not found'});
    }
    else{
      user.expiredDate = req.body['expiredDate'];
      user.save().then((response) => {
        res.status(200).json({'message':'updateExpiredDate Successfully',"user":response});
      }, (error) => {
        res.status(400).json(error);
      })
    }
  });
});

router.post('/getDetail/:username',ApiAuthenticated, function(req,res) {
  let username = req.params.username;
  console.log(username);
  UserModel.findOne({username:username, role:'User'}, function(err, user) {
    if(err || ! user)
    {
      return res.status(400).json({'message':'User not found'});
    }
    else{

      DataUsageLogModel.findOne({username:username}, function(err, userDataUsage) {
        console.log(err)
        console.log(userDataUsage);
        if(err || !userDataUsage)
          dataUsage = 0;
        else
          dataUsage = userDataUsage.dataUsage;
        mb_value = dataUsage / 1024 / 1024;
        mb_value = Number(mb_value.toFixed(2));
        res.status(200).json({'message':'success', data:{
                                                          username:user.username,
                                                          dataUsage: mb_value,
                                                          dataLimit: user.dataLimit,
                                                          portRange: user.portRange                                                          
                                                        }
        });
      });
    }
  });
});


router.post('/port/create', ApiAuthenticated, validate(createPortValidation), function(req,res) {
  const portNumber = req.body.port;
  const server = req.body.server;
  const proxyInfo = req.body.path;
  const requestBody = {
    portNumber:portNumber,
    proxyInfo:proxyInfo
  }
  const thisIns = this;
  const options ={
    url:`http://${server}:${AdminPort}/create`,
    method: 'POST',
    headers: {
      "Authorization": SecretKey
    },
    body: requestBody,
    json:true

  }
  request( options,
    (err, apiRes, body) => {
      if(err){
        console.log(err);
        return res.status(400).json({'msg':'Unknown Error'});
      }
      res.json(body);
    });

});

router.post('/port/delete', ApiAuthenticated, validate(deletePortValidation), function(req,res) {
  const portNumber = req.body.port;
  const server = req.body.server;
  const requestBody = {    
    portNumber:portNumber
  }
  const thisIns = this;
  const options ={
    url:`http://${server}:${AdminPort}/delete`,
    method: 'POST',
    headers: {
      "Authorization": SecretKey
    },
    body: requestBody,
    json:true

  }
  request( options,
    (err, apiRes, body) => {
      if(err){
        console.log(err);
        return res.status(400).json({'msg':'Unknown Error'});
      }
      res.json(body);
    });
});
module.exports = router;