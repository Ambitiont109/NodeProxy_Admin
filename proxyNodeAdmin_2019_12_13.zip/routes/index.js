var express = require('express');
var mongoose = require('mongoose');
const Bcrypt = require("bcryptjs");
var router = express.Router();
var {isAuthenticated} = require('../middleware.js');
/* GET home page. */
router.get('/', isAuthenticated, function(req, res, next) {
  res.redirect('/users/list');
});

router.get('/dashboard', isAuthenticated, function(req, res, next) {
	res.render('index', {activePage:'dashboard', messages:req.flash('messages')});
});

router.get('/logout', isAuthenticated, function(req, res, next) {
	delete req.session['current_user'];
	res.redirect('/login');
});

router.get('/login' ,function(req, res, next) {
	res.render('login', {email:undefined, error:undefined});
});
router.post('/login', function(req,res) {
	console.log(req.body);
	var UserModel = mongoose.model('User');
	UserModel.findOne({email: req.body.email}, function(err, user) {
		console.log("Find one");
		console.log(user)
		console.log(err)
    	if (err) throw err;
    	if(!user){
    		res.render('login', { error:'User not found.' , email: req.body.email});
    	} else if (user){
    		if(!Bcrypt.compareSync(req.body.password, user.password))
    			res.render('login', {error: 'Password is Invalid', email: req.body.email});
    		else{
    			console.log('Passed')
    			req.session.current_user = user;
    			console.log(req);
    			res.redirect('/users/list');    			
    		}
    	}    	
	});	
})

router.post('/delete_user/:username',isAuthenticated, function(req,res) {
  let username = req.params.username;
  var UserModel = mongoose.model('User');
  var DataUsageLogModel = mongoose.model('DataUsageLog');
  UserModel.deleteOne({username:username}, function(err) {
    DataUsageLogModel.deleteOne({username:username}, function(err) {
    });
    if (!err)
      req.flash('messages', {tag:'success', content:`Delete User: ${username} successfully`});
    res.redirect('/users/list');
  })
});


router.get('/import/proxy', isAuthenticated, function(req, res, next) {
  res.render('import_proxy', {activePage:'ImportProxy', messages:req.flash('messages')});
});

router.post('/import/proxy', isAuthenticated, function(req, res, next) {
  var basePath = 'D:\\DOWNLOAD\\Employers\\Richard\\node-proxy\\';
  var initJsonPath = basePath + 'init.json';
  var masterPidPath = basePath + 'master.pid';
  var runbatPath = basePath + 'run.bat';
  var massProxy = req.body.massproxy;
  var lines = massProxy.split('\n');
  console.log(lines.length);
  var routeTable = {};
  for(var i = 0;i < lines.length;i++){
    //code here using lines[i] which will give you each line

    var line = lines[i];
    console.log(line);
    var details = line.split(':');
    console.log(details);
    if(details.length!=5)
      continue;
    for (var j= details.length - 1; j >= 0; j--) {
      details[j] = details[j].trim();
    }
    routeTable[details[0]] = `${details[1]}:${details[2]}:${details[3]}:${details[4]}`;
  }
  var fs = require('fs');
  var ps = require('ps-node');
  let jsonContent;
  try{
    let content = fs.readFileSync(initJsonPath);
    jsonContent = JSON.parse(content);
    console.log(jsonContent);
  } catch (err){
    console.log(err);
    req.flash('messages', {tag:'warning', content:`Error`});
    res.redirect('/import/proxy');
  }
  jsonContent['RouteTable'] = routeTable;
  fs.writeFileSync(initJsonPath, JSON.stringify(jsonContent));
  let masterPid = fs.readFileSync(masterPidPath);
  ps.kill(masterPid, function( err ) {
      if (err) {
        if(err.code != "ERSCH"){
          console.log(err)
          req.flash('messages', {tag:'warning', content:`Error`});
          res.redirect('/import/proxy');          
        }
      }
      else {
        console.log("proxy server has been killed");
        var shell = require('shelljs');
        shell.exec(runbatPath, {async:true});        
        req.flash('messages', {tag:'success', content:`Resetted`});
        res.redirect('/import/proxy');
      }
  });  
  
});

module.exports = router;
