var express = require('express');
var mongoose = require('mongoose');

var router = express.Router();
var utils = require('../utils.js');
var {isAuthenticated} = require('../middleware.js');
var UserModel = mongoose.model('User');
var DataUsageLogModel = mongoose.model('DataUsageLog');
var LogModel = mongoose.model('Log');
/* GET users listing. */
router.get('/', isAuthenticated, function(req, res, next) {
  res.send('respond with a resource');
  next();
});

router.get('/list', isAuthenticated, function(req, res, next) {
  let users =undefined;
  let dataUsages = undefined;
  let countOfProcess = 0;  
  UserModel.find({role:'User'},function(err,docs){
    console.log(docs)
    users = docs
    if(users && dataUsages)
      res.render('users/list_user', {users:users, dataUsages:dataUsages, MBFormat:utils.MBFormat ,activePage:'users', messages:req.flash('messages')});
  });
  DataUsageLogModel.find({}, function(err, docs) {
    dataUsages = {};
    docs.forEach(doc=> { 
      dataUsages[doc.username] = {dataUsage: doc.dataUsage};
    })
    if(users && dataUsages)
      res.render('users/list_user', {users:users, dataUsages:dataUsages, MBFormat:utils.MBFormat ,activePage:'users', messages:req.flash('messages')});
  })
});

router.get('/detail/:username', isAuthenticated, function(req, res, next) {
  let username = req.params.username;
  // var UserModel = mongoose.model('User');
  console.log(req.params)

  UserModel.findOne({username:username, role:'User'}, function(err, user) {
    if(err || ! user)
    {
      console.log(err,user)
      return next();
    }
    res.render('users/detail_user', {user:user, username:username, error:{errors:{}}, activePage:'users', messages:req.flash('messages'), });
  });
})

router.post('/detail/:username', isAuthenticated, function(req, res) {
  let username = req.params.username;
  // var UserModel = mongoose.model('User');
  console.log(req.params)
  
  let range = req.body['portRange'].split(';');
  req.body['portRange']={start:range[0],end:range[1]}
  console.log(req.body)
  UserModel.findOneAndUpdate({username: username}, req.body,{runValidators:true, context: 'query'},  function(err, user){
    console.log(user);
    console.log('======');
    console.log(err);
    if(err|| !user){
      console.log(err, user);
      res.render('users/detail_user', {user:req.body,username:username, error:err, activePage:'users',messages:req.flash('messages')})
    } else {
      req.flash('messages', {tag:'success', content:'User Updated Successfully'});
      res.redirect('/users/list');      
    }
  })
})

router.post('/detail/:username/setpassword', isAuthenticated, function(req, res) {
  let username = req.params.username;
  // var UserModel = mongoose.model('User');
  console.log(req.params)
  UserModel.findOneAndUpdate({username: username}, req.body, function(err, user){
    if(err|| !user){
      console.log(err, user);
      res.render('users/detail_user', {user:req.body, username:username, error:err, activePage:'users', messages:req.flash('messages')})
    } else {
      req.flash('messages', {tag:'success', content:'Password has been changed Successfully'});
      res.redirect('/users/list');
    }
  })
})

router.get('/detail/:username/sitelog', isAuthenticated, function(req, res) {
  let username = req.params.username;
  // var UserModel = mongoose.model('User');
  console.log(req.params)
  LogModel.find({username: username}, function(err, docs){
    let logs = [];
    if(docs)
      logs = docs
    res.render('users/detail_sitelog', {logs:logs, activePage:'users', messages:req.flash('messages')});
  })
})

router.get('/add_user', isAuthenticated, function(req,res) {
  res.render('users/add_user', {error:{errors:{}}, activePage:'users', user:{}, messages:req.flash('messages')})
});

router.post('/add_user'/*,isAuthenticated*/, function(req,res) {
  // var UserModel = mongoose.model('User');
  let range = req.body['portRange'].split(';');
  req.body['portRange']={start:range[0],end:range[1]}
  console.log(req.body)
  let user = new UserModel(req.body);
  console.log(user);
  console.log("===========")
  user.save().then((response) => {
      req.flash('messages', {tag:'success', content:'User Added Successfully'});
      res.redirect('/users/list');
      let dataDoc = new DataUsageLogModel({username:user.username, dataUsage:0});
      dataDoc.save();
    }, (error) => {      
      res.render('users/add_user', {error:error, activePage:'users', user:user, messages:req.flash('messages')})
  });
});

module.exports = router;

