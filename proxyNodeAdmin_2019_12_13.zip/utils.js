function MBFormat(byte_value){
	if(!byte_value)
		return '0.00MB'
	mb_value = byte_value / 1024 / 1024
	return mb_value.toFixed(2) + 'MB';
}

module.exports = {
	MBFormat: MBFormat,
}